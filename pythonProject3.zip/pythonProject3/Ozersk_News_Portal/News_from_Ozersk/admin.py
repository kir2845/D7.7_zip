from django.contrib import admin
from .models import Category, New, Author1


admin.site.register(Category)
admin.site.register(New)
admin.site.register(Author1)
